# Handover Assets

This directory contains visual aids for handover.

`tiinex-handover-package.png` is intended for continuation onboarding. It should not be treated as machine-readable authority.
