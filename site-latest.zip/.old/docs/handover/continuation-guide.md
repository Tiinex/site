# Continuation Guide

Status: supporting handover document, not a schema artifact.

## Base Assumption

Work from the latest published public version or the current source zip handed off by Q.

If replacing a repository with the zip contents, preserve only the receiving repo's `.git/` directory. The source package should otherwise be treated as complete.

## Grounding Order

1. Read repository identity and context files.
2. Read architecture docs in `docs/architecture/`.
3. Read current source and diagnostics before proposing changes.
4. Check Tiinex/docs schemas when changing schema interpretation, validation, capability behavior, or fallback behavior.
5. Prefer local evidence over memory.

## Development Discipline

Legacy runtime boundary:

- Treat `app.js` as a legacy behavior reference during the React/structured-runtime migration.
- Do not develop app.js forward or patch new architecture into it.
- New ownership should land in scalable source directories with tests/checks, then replace the legacy path only when the new app can carry the behavior.

Before changing code, identify the likely owner:

- schema or Tiinex format;
- schema module or capability declaration;
- runtime interpreter;
- source adapter;
- UI presentation layer;
- documentation bridge;
- temporary experimental implementation.

Do not patch the UI when the real problem is schema/runtime ownership.

## First Code Iteration Recommendation

Create a small schema-runtime foundation with unit tests before wiring major UI behavior.

Recommended modules:

- `src/schema-runtime/registry.js`
- `src/schema-runtime/inheritance.js`
- `src/schema-runtime/capability-resolution.js`
- colocated tests next to those modules

Minimum tests:

- exact schema capability resolves first;
- missing child capability falls back to parent;
- unknown child with known parent stays usable;
- unknown schema falls back to root with degraded disclosure;
- missing capability is unavailable, not invented;
- fallback result records what happened.

## Manual Test Gate

Documentation-only iterations usually do not need heavy manual testing.

Any iteration that changes app boot, `index.html`, runtime file loading, navigation, hash restore, local draft behavior, source resolution, rendering, or publish packaging should be tested locally through `index.html` before the next dependent iteration.

## Validation Commands

Run locally when relevant:

- `node --check app.js`
- `npm run validate`
- `npm run metrics`
- `npm run storage:scan`

Do not run public publish/deploy manually when GitHub workflow owns it. If public build output is needed for verification, say that explicitly and keep it separate from deployment.

## Communication Requirements

When handing off, name:

- base zip or commit;
- what changed;
- validation commands run;
- what was intentionally not run;
- open risks;
- whether Q needs to test before the next iteration.
