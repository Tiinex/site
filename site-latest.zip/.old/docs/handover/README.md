# Tiinex Site Handover Package

Status: supporting handover document, not a schema artifact.

This package is for the next developer or LLM continuing `Tiinex/site` work. It assumes the handover base is the latest published public version of the site or the zip package provided for the current iteration.

Do not assume unmerged local experiments exist in the fork base.

## Start Here

1. Read `../../tiinex.orientation.v1.md`.
2. Read `../../tiinex.context.v1.md`.
3. Read `../../README.md`.
4. Read `../../tiinex.app.llm.v1.md`.
5. Read `../architecture/README.md`.
6. Read `continuation-guide.md`.

## Visual Handover Map

![Tiinex Handover Package](assets/tiinex-handover-package.png)

This image is a visual onboarding map. It is not machine-readable authority. Use the Markdown and Tiinex schemas for exact behavior.

## Current Direction

Schemas in Tiinex format should define behavior. Runtime should interpret schemas and capabilities. UI should present runtime results.

Supporting Markdown exists only to bridge behavior that has not yet been formalized as schema.

Experimental implementation must be visible, documented, and planned for lifting into schema/runtime design.

## First Development Target

The next implementation work should create a schema-runtime foundation, not another UI patch.

Expected first code direction:

- schema capability registry;
- context-aware capability resolution;
- parent/root fallback behavior;
- fallback diagnostics;
- colocated tests near new runtime modules;
- no new schema-specific logic in `app.js`.
