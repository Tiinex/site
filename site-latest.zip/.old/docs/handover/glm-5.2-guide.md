# GLM 5.2 Continuation Notes

Status: supporting handover document, not a schema artifact.

This document exists because the handover was originally expected to be continued by a GLM 5.2-based workflow. It remains useful for any LLM.

## Operating Posture

Be conservative, source-grounded, and explicit about uncertainty.

Do not optimize for persuasive confidence. Optimize for recoverable, inspectable progress.

## Do First

- Read architecture docs before editing runtime code.
- Read Tiinex/docs schemas before changing schema semantics.
- Inspect the actual repo state before making claims.
- Preserve source/draft/local boundaries.
- Keep changes small enough to validate.

## Avoid

- Adding one more UI special case.
- Treating Markdown prose as validation authority.
- Treating generated images as schema authority.
- Guessing GitHub source for local draft material.
- Calling a task finished because code changed but diagnostics were not run.

## Useful Framing

The app is not the semantic owner.

Schemas define behavior. Runtime interprets. UI presents.

If a behavior is not schema-backed yet, document it as bridge material and make the migration path visible.
