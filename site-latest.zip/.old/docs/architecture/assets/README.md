# Architecture Assets

This directory contains architecture vision images.

- `tiinex-architecture-vision.png` is the public-facing vision candidate.
- `tiinex-architecture-overview.png` is the more detailed technical overview.

Generated image text should be reviewed by a human before public use.
