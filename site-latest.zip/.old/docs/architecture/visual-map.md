# Visual Map Usage

Status: supporting architecture document, not a schema artifact.

## Public Vision Image

File: `assets/tiinex-architecture-vision.png`

Purpose: public-facing vision map for the GitHub organization or project overview.

Use this image where the audience needs the target architecture in one visual pass. It should replace the older vision map only after a human has zoomed in and accepted the generated image text.

Suggested public repo path outside this site package:

- `Tiinex/.github/assets/architecture/tiinex-architecture-vision.png`

Suggested usage:

- `Tiinex/.github/profile/README.md`

## Technical Overview Image

File: `assets/tiinex-architecture-overview.png`

Purpose: detailed architecture orientation for repo docs.

Use this image in this repo under architecture documentation, not as the first public marketing image.

## Handover Image

File: `../handover/assets/tiinex-handover-package.png`

Purpose: practical continuation map for the next human or LLM.

Use this image in handover packages, not as the public vision image.

## Image Authority Limit

The images are not schema authority. They are onboarding maps.

If the images contain any text error, ambiguity, or conflict with Markdown or Tiinex schemas, the Markdown and schemas win.
