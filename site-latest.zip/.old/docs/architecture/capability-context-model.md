# Capability And Context Model

Status: supporting architecture document, not a schema artifact.

## Key Distinction

Context belongs to the app.

Behavior belongs to the schema.

The app may know that the user is in feed, detail, graph, create, edit, audit, tree, or another bounded surface. The app must not hardcode what a specific schema should do in that context.

## Capability Families

A schema or schema module may provide capabilities such as:

- presentation: how artifact material may be shown in a context;
- interaction: what actions are available;
- form: how creation or editing should be structured;
- validation: what can be checked and what cannot;
- relations: how related artifacts are discovered, shown, or traversed;
- handover: what a human or LLM needs to continue safely.

A schema may implement all, some, or none of these capability families. Missing capability is not failure by itself. It triggers inheritance and fallback.

## Context Examples

- Feed: scan many items quickly.
- Detail: inspect one item more deeply.
- Graph: explore relationships and lineage.
- Create: create a new artifact with the fields needed for the current context.
- Edit: modify an existing artifact, possibly with more detail than quick-create.
- Audit: review validation, lineage, integrity, and source boundaries.
- Tree: navigate hierarchy; this may use a more uniform surface than feed/detail.

## Fast Workflows

Some contexts should intentionally show fewer fields and fewer actions so work stays fast.

Other contexts should expose deeper controls.

This should be declared through schema-owned or schema-module-owned capabilities, not through UI special cases.

## Future Builder Requirement

Schema builders and dynamic forms require capabilities to be machine-readable or at least structured enough to be lifted into Tiinex format.

A form field should eventually be an interaction unit or a schema-derived construct, not a hardcoded component choice.
