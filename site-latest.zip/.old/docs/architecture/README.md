# Tiinex Architecture Direction

Status: supporting architecture document, not a schema artifact.

This directory records the agreed architecture direction for `Tiinex/site` after the current checkpoint discussion. It is intentionally written in plain Markdown so humans and LLMs can continue implementation without re-grounding the whole conversation.

Schemas in Tiinex format remain the primary source of truth. These documents are bridge material for behavior that is not fully formalized as schema yet.

## Read This First

1. `architecture-direction.md` — the target model and non-negotiable boundaries.
2. `schema-governance-model.md` — schema, supporting-doc, and implementation governance levels.
3. `capability-context-model.md` — how contexts ask schemas for behavior.
4. `inheritance-and-fallback.md` — how unknown or incomplete schemas remain usable.
5. `implementation-limits.md` — what must not be hidden in code.
6. `visual-map.md` — how the architecture images should be used.

## Visuals

- `assets/tiinex-architecture-vision.png` is the public-facing vision image candidate.
- `assets/tiinex-architecture-overview.png` is the technical overview image for architecture docs.

The images are visual maps, not machine-readable authority. If image text and Markdown disagree, use the Markdown and Tiinex schemas.

## North Star

Schemas define behavior. Runtime interprets. UI presents.

Everything important should become expressible in Tiinex format over time.
