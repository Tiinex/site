# Inheritance And Fallback Model

Status: supporting architecture document, not a schema artifact.

## Goal

The app should remain useful when a schema is unknown, incomplete, experimental, or only partially implemented.

Unknown does not mean broken. Unknown means the runtime must disclose what it does and does not know.

## Resolution Order

For each requested capability:

1. Try the exact schema.
2. If missing, try the parent schema.
3. Continue climbing the schema hierarchy.
4. Use the nearest known schema family behavior when available.
5. Fall back to root envelope behavior.
6. Return the result with fallback disclosure.

## Root Fallback

Root fallback can preserve basic artifact readability, continuity envelope handling, identity, and safety boundaries.

Root fallback must not silently claim child-schema-specific validity, completeness, or meaning.

## Unknown Child Schema

If a child schema is unknown but its parent is known:

- parent behavior may still be used;
- child-specific behavior is unavailable;
- the UI must disclose degraded or inherited behavior;
- validation must not pretend the child-specific contract was checked.

## Missing Capability

If a capability is not provided:

- do not invent it from prose;
- do not patch it in the UI;
- return unavailable, inherited, or root-fallback status;
- surface that status in diagnostics and, when relevant, in the UI.

## Why This Matters

Fallback is how Tiinex can support open-ended schema growth without forcing every implementation to know every schema in advance.
