# Schema Governance Model

Status: supporting architecture document, not a schema artifact.

## Three Governance Levels

### 1. Schemas in Tiinex format

This is the primary authority.

Schemas define artifact meaning, validation surfaces, capabilities, inheritance, fallback, relationships, presentation surfaces, interaction units, creation behavior, and other durable semantics when those concepts are formalized.

Important behavior should move here whenever possible.

### 2. Supporting Markdown documents

This is bridge material.

Supporting documents explain architecture, current decisions, migration plans, open risks, and behavior that is not yet formalized as schema.

Supporting documents must be clear enough that later work can lift them into Tiinex format without rediscovering the reasoning.

### 3. Experimental implementation

This is temporary.

Code may contain experimental behavior while the system is being discovered, but that behavior must be documented and planned for lifting into schemas or supporting governance docs.

Implementation must not be the only place where important behavior exists.

## Rule For Gaps

If behavior exists only in code, it is invisible to the Tiinex system.

If it affects interpretation, validation, forms, presentation, graph behavior, source boundaries, handover, or lineage continuity, document it and move it toward Tiinex format.

## Relationship To Root Schema

The root schema defines the minimum shared artifact contract and machine-authority boundaries. Architecture documents must not redefine root semantics or invent validation requirements from prose.

Architecture documents may guide implementation, but validators must read machine-authoritative schema contract surfaces rather than treating explanatory prose as validation law.
