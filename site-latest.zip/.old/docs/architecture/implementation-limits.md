# Implementation Limits

Status: supporting architecture document, not a schema artifact.

## Not Allowed

- Do not add schema-specific logic directly in `app.js`.
- Do not add schema-specific if/else branches in UI rendering.
- Do not infer validation requirements from explanatory prose.
- Do not guess behavior that is not declared by schema, module, capability, or documented fallback.
- Do not treat local or draft material as published source.
- Do not collapse Parent, Origin, source, external container, and publication target into one relation.
- Do not create a feature that only works because one UI surface knows one schema.

## Required

- Keep local/draft and source-backed boundaries visible.
- Preserve continuity and lineage across views, shares, imports, exports, and edits.
- Make fallback and degraded behavior visible.
- Add diagnostics when behavior could regress.
- Validate with local commands before handing off.
- Document experimental behavior before relying on it.
- Prefer reusable schema/runtime capability design over UI patches.

## Architecture Failure Signals

The architecture has drifted when:

- adding a schema requires changing a UI component;
- a user cannot tell whether fallback was used;
- a validator claims more than the loaded schema contract supports;
- behavior exists only as code with no schema or supporting document;
- source boundaries become ambiguous;
- local/offline/draft workflows break while improving public/published flows.

## Recovery Pattern

When drift is found:

1. Name the behavior.
2. Identify whether it belongs in schema, schema module, interaction unit, presentation surface, runtime, adapter, or UI.
3. Document the current temporary behavior.
4. Move ownership upward when the root cause is clear.
5. Add diagnostics or tests so the boundary does not regress.
