# Architecture Direction

Status: supporting architecture document, not a schema artifact.

## Target Model

`Tiinex/site` should behave as a schema-driven runtime for Tiinex artifacts.

The runtime should not be a collection of UI special cases. It should load artifacts, identify schemas, resolve capabilities, apply inheritance and fallback, and return normalized results that the UI can present.

The UI is a presentation layer. It knows where the user is and what interaction context is active. It must not become the semantic authority for schema behavior.

## Core Principle

Do not build schema behavior directly into the app.

Define behavior in schemas or in supporting Markdown that is explicitly marked as bridge material until it can be lifted into Tiinex format.

If a new schema requires an app-specific patch to work, the architecture has drifted. The correct response is to move the behavior upward into schema, schema module, capability, runtime, or fallback design.

## System Flow

1. The UI provides context: feed, detail, graph, create, edit, audit, tree, or another bounded surface.
2. The runtime loads the artifact and identifies its current schema.
3. The runtime resolves the requested capability for that schema and context.
4. Missing behavior is resolved through parent schemas and then root fallback.
5. The UI presents the result and clearly discloses fallback or degraded behavior.

## What This Enables

- Add more schemas without rewriting the app.
- Keep unknown child schemas usable through parent or root behavior.
- Support schema-driven forms, graph behavior, validation, handover, and future builders.
- Make behavior portable beyond this browser app.
- Reduce re-grounding for future developers and LLMs.

## Current Reality

The existing repo already has schema-first direction and a working viewer, but not all behavior is formalized as schema. Some behavior still exists as experimental code, app-shell logic, or partially documented conventions.

That is acceptable only when visible. Hidden behavior in code is technical debt and should be lifted into schema or supporting documentation over time.
