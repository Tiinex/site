export const surfaceCapabilities = Object.freeze({
  "canCreateArtifact": true,
  "canBeParent": true,
  "canRenderFallback": false,
  "supportedSurfaces": [
    "feed",
    "tree",
    "detail",
    "lineage",
    "preview",
    "share",
    "graph"
  ]
});
