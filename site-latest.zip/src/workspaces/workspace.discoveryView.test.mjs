import assert from 'node:assert/strict';
import { createRecordFromMarkdown } from '../artifacts/artifact.record.js';
import { buildWorkspaceDiscoveryView, buildDiscoveryMaterialIndex, isDiscoveryLeafRecord } from './workspace.discoveryView.js';
import { buildWorkspacePathTree } from './workspace.pathTree.js';
import { buildWorkspaceLineageView } from './workspace.lineageView.js';

function artifactMarkdown({ title, summary, schema = 'tiinex.topic.v1', parentTrace = '', parentLabel = '001.trace.md' }) {
  const parentBlock = parentTrace ? `- Parent\n  - Parent Schema: [tiinex.topic.v1](tiinex.topic.v1.schema.md)\n  - Trace: [${parentLabel}](${parentTrace})\n` : '';
  return `# Continuity Context\n\n- Envelope Schema: [tiinex.root.v1](tiinex.root.v1.schema.md)\n${parentBlock}- Current\n  - Current Schema: [${schema}](${schema}.schema.md)\n  - Created At: 2026-07-23T00:00:00.000Z\n  - Summary: ${summary}\n\n---\n\n# ${title}\n\n## Summary\n\n${summary}\n\n# Continuity Integrity\n\n- Method: pending\n  - Value: pending\n`;
}

function sourceBackedRecord(markdown, path, extra = {}) {
  return Object.assign(createRecordFromMarkdown(markdown, {
    path,
    sourceMode: 'source-backed'
  }), {
    id: extra.id || path,
    sourceMode: 'source-backed',
    source: { id: 'github:Tiinex/docs@master:.topics', adapterId: 'github', kind: 'github-tree', repo: 'Tiinex/docs', ref: 'master', rootPath: '.topics', label: 'Tiinex/docs' }
  }, extra);
}

const educationalRoot = sourceBackedRecord(artifactMarkdown({
  title: 'Educational Root',
  summary: 'Educational branch root.'
}), '.topics/educational/001.trace.md');

const slidesBranch = sourceBackedRecord(artifactMarkdown({
  title: 'Slides Branch',
  summary: 'Slides branch under educational root.',
  parentTrace: '../001.trace.md'
}), '.topics/educational/slides/001.trace.md');

const terminalSlide = sourceBackedRecord(artifactMarkdown({
  title: 'Expert First Diagrams',
  summary: 'Terminal work leaf under slides branch.',
  parentTrace: '../001.trace.md'
}), '.topics/educational/slides/expert-first/001.trace.md');

const socialsRoot = sourceBackedRecord(artifactMarkdown({
  title: 'Socials Branch',
  summary: 'Socials folder root.'
}), '.topics/socials/discord/tiinex/001.trace.md');

const socialsTask = sourceBackedRecord(artifactMarkdown({
  title: 'Echo Cloud Handoff',
  summary: 'Task under socials root.',
  schema: 'tiinex.task.v1',
  parentTrace: './001.trace.md'
}), '.topics/socials/discord/tiinex/001-I-echo-cloud-handoff.trace.md');

const metadataOnlyAdapter = {
  id: '.topics/.adapters/github/discussion.adapter.md',
  title: 'GitHub Discussion Discovery Adapter',
  path: '.topics/.adapters/github/discussion.adapter.md',
  schemaId: 'tiinex.adapter.v1',
  kind: 'tiinex.adapter.v1',
  sourceMode: 'source-backed',
  source: { id: 'github:Tiinex/docs@master:.topics', adapterId: 'github', rootPath: '.topics', label: 'Tiinex/docs' },
  trace: '../001.trace.md',
  hasContinuityContext: true,
  hasIntegrity: true,
  cacheState: 'source-backed-metadata-only-session-cache'
};

const routeShell = {
  id: 'route-shell',
  title: 'Route Shell',
  path: '.topics/route/001.trace.md',
  schemaId: 'tiinex.topic.v1',
  sourceMode: 'source-backed',
  source: { id: 'github:Tiinex/docs@master:.topics', adapterId: 'github', rootPath: '.topics', label: 'Tiinex/docs' },
  hasContinuityContext: true,
  cacheState: 'route-shell-material-unavailable',
  materialAvailability: 'material-unavailable'
};


const pathOnlyParent = sourceBackedRecord(artifactMarkdown({
  title: 'Path Only Root',
  summary: 'Branch root whose child lacks a declared trace.'
}), '.topics/path-only/001.trace.md');

const pathOnlyChild = sourceBackedRecord(artifactMarkdown({
  title: 'Path Only Child',
  summary: 'Terminal child under path-only branch.'
}), '.topics/path-only/child/001.trace.md');

const records = [educationalRoot, slidesBranch, terminalSlide, socialsRoot, socialsTask, pathOnlyParent, pathOnlyChild, metadataOnlyAdapter, routeShell];
const workspace = { id: 'workspace:discovery-test', title: 'Discovery test', records, assets: [], workspaceMergeCandidates: [] };
const view = buildWorkspaceDiscoveryView(workspace, {
  displayOptions: { leavesOnly: true, showSupportingMarkdown: true, showWorkspaceCandidates: false, showAssets: false },
  query: ''
});

assert.deepEqual(view.records.map((record) => record.path).sort(), [
  '.topics/educational/slides/expert-first/001.trace.md',
  '.topics/path-only/child/001.trace.md',
  '.topics/socials/discord/tiinex/001-I-echo-cloud-handoff.trace.md'
], 'Leaves only shows terminal work leaves only, even when Supporting docs is checked');
assert.equal(view.hiddenReasonsById.get(educationalRoot.id), 'hidden-loaded-parent', 'Educational Root is hidden as a resolved loaded parent');
assert.equal(view.hiddenReasonsById.get(pathOnlyParent.id), 'hidden-path-parent', 'Path-only branch root is hidden by path-parent fallback even without a declared trace edge');
assert.equal(view.hiddenReasonsById.get(slidesBranch.id), 'hidden-loaded-parent', 'Slides Branch is hidden as a resolved loaded parent');
assert.equal(view.hiddenReasonsById.get(socialsRoot.id), 'hidden-loaded-parent', 'Folder 001.trace.md parent is hidden when a sibling child declares it');
assert.equal(view.hiddenReasonsById.get(metadataOnlyAdapter.id), 'hidden-supporting', 'metadata-only adapter support is hidden from Leaves only');
assert.equal(view.hiddenReasonsById.get(routeShell.id), 'hidden-supporting', 'route-only unavailable shell is hidden from Leaves only');

const index = buildDiscoveryMaterialIndex(records);
assert.equal(isDiscoveryLeafRecord(educationalRoot, index), false, 'path branch roots are not Discovery leaves');
assert.equal(isDiscoveryLeafRecord(socialsRoot, index), false, 'same-folder 001.trace.md roots are not Discovery leaves when they have child work records');
assert.equal(isDiscoveryLeafRecord(socialsTask, index), true, 'terminal same-folder child remains a Discovery leaf');

const tree = buildWorkspacePathTree({ records: view.records, assets: view.assets, workspaceCandidates: view.workspaceCandidates, rootLabel: 'Visible tree' });
const treeJson = JSON.stringify(tree);
assert.equal(treeJson.includes('Educational Root'), false, 'Tree read-model uses same Discovery membership and hides parent root records');
assert.equal(treeJson.includes('Slides Branch'), false, 'Tree read-model uses same Discovery membership and hides branch parent records');
assert.equal(treeJson.includes('Socials Branch'), false, 'Tree read-model uses same Discovery membership and hides same-folder 001.trace.md parents');
assert.equal(treeJson.includes('Path Only Root'), false, 'Tree read-model hides path-only branch parents');
assert.equal(treeJson.includes('Path Only Child'), true, 'Tree still includes path-only terminal child');
assert.equal(treeJson.includes('Expert First Diagrams'), true, 'Tree still includes terminal work leaf');
assert.equal(treeJson.includes('Echo Cloud Handoff'), true, 'Tree still includes terminal sibling work leaf');
assert.equal(treeJson.includes('GitHub Discussion Discovery Adapter'), false, 'Tree hides support records under Leaves only');

const lineage = buildWorkspaceLineageView(workspace, { records, selectedRecordId: terminalSlide.id });
assert.deepEqual((lineage.selectedTraversal?.nodes || []).map((node) => node.id), [terminalSlide.id, slidesBranch.id, educationalRoot.id], 'Lineage still traverses parent/root chain independent of Discovery membership');


const syntheticRecords = Array.from({ length: 325 }, (_, index) => ({
  id: `synthetic-${index}`,
  title: `Synthetic ${index}`,
  path: `.topics/perf/group-${Math.floor(index / 10)}/child-${index % 10}/001.trace.md`,
  sourcePath: `.topics/perf/group-${Math.floor(index / 10)}/child-${index % 10}/001.trace.md`,
  schemaId: 'tiinex.topic.v1',
  kind: 'tiinex.topic.v1',
  sourceMode: 'source-backed',
  source: { id: 'github:Tiinex/docs@master:.topics', adapterId: 'github', rootPath: '.topics', label: 'Tiinex/docs' },
  hasContinuityContext: true,
  hasIntegrity: true
}));
const startedAt = Date.now();
buildWorkspaceDiscoveryView({ id: 'workspace:perf', records: syntheticRecords }, {
  displayOptions: { leavesOnly: true, showSupportingMarkdown: false, showWorkspaceCandidates: false, showAssets: false },
  query: ''
});
const elapsed = Date.now() - startedAt;
assert.ok(elapsed < 1000, `Discovery membership for 325 records should stay render-safe; took ${elapsed}ms`);

console.log('✓ workspace.discoveryView integration tests passed');
