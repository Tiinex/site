export function checkIntegrity() { return []; }
