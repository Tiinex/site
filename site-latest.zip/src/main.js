(() => {
  'use strict';

  const lifecycle = window.TiinexWorkspaceLifecycle;
  const route = window.TiinexWorkspaceRoute;
  const persistence = window.TiinexWorkspacePersistence;
  const root = document.getElementById('root');
  const VERSION_LABEL = 'v115 source progress parity';
  const workspaceConfig = window.TiinexWorkspaceConfig?.createDefaultWorkspaceConfig?.() || { emptyStage: { subtitles: ['Everything starts from somewhere.'] }, viewerIdentity: { browserTitle: 'Tiinex' }, help: [] };
  const iconPaths = window.TiinexIconPaths || {};
  if (workspaceConfig.viewerIdentity?.browserTitle && document?.title !== undefined) document.title = workspaceConfig.viewerIdentity.browserTitle;
  if (!root || !lifecycle || !persistence || !route) return;

  let state = hydrateState();
  let dialog = null;
  let notice = '';

  render();
  bindRouteEvents();

  function hydrateState() {
    const restored = persistence.readInitialState();
    return route.normalizeRouteState(restored, lifecycle);
  }

  function commit(next, mode = 'replace') {
    state = route.normalizeRouteState(next, lifecycle);
    if (state.workspaces?.length) persistence.writeState(state, { mode });
    else persistence.clearState?.({ mode });
    render();
  }

  function restoreFromLocation() {
    state = hydrateState();
    dialog = null;
    notice = '';
    render();
  }

  function bindRouteEvents() {
    window.addEventListener?.('popstate', restoreFromLocation);
    window.addEventListener?.('hashchange', restoreFromLocation);
  }

  function render() {
    const active = lifecycle.activeWorkspace(state);
    root.innerHTML = renderApp(active);
    bindEvents();
  }

  function bindEvents() {
    root.querySelectorAll('[data-home]').forEach((button) => button.addEventListener('click', goHome));
    root.querySelectorAll('[data-create-workspace]').forEach((button) => button.addEventListener('click', () => openDialog('create-workspace')));
    root.querySelectorAll('[data-close-workspace]').forEach((button) => button.addEventListener('click', () => openCloseDialog(button.getAttribute('data-close-workspace'))));
    root.querySelectorAll('[data-multiverse]').forEach((button) => button.addEventListener('click', () => openDialog('multiverse')));
    root.querySelectorAll('[data-help]').forEach((button) => button.addEventListener('click', () => openDialog('help')));
    root.querySelectorAll('[data-share]').forEach((button) => button.addEventListener('click', () => openDialog('share')));
    root.querySelectorAll('[data-copy-share]').forEach((button) => button.addEventListener('click', () => copyShareUrl(button.getAttribute('data-copy-share'))));
    root.querySelectorAll('[data-verse]').forEach((button) => button.addEventListener('click', () => commit(lifecycle.setWorkspaceVerse(state, button.getAttribute('data-verse')), 'push')));
    root.querySelectorAll('[data-workspace-action]').forEach((button) => button.addEventListener('click', () => openWorkspaceAction(button.getAttribute('data-workspace-action'), button.getAttribute('data-workspace-id'))));
    root.querySelectorAll('[data-close-source]').forEach((button) => button.addEventListener('click', () => closeWorkspaceSource(button.getAttribute('data-workspace-id'), button.getAttribute('data-close-source'))));
    const search = root.querySelector('#workspace-search');
    if (search) search.addEventListener('input', () => {
      const next = lifecycle.cloneState(state);
      next.view.query = search.value;
      commit(next, 'replace');
    });
    const createForm = root.querySelector('#create-workspace-form');
    if (createForm) createForm.addEventListener('submit', (event) => submitCreateWorkspace(event, createForm));
    const addMaterialForm = root.querySelector('#add-material-form');
    if (addMaterialForm) addMaterialForm.addEventListener('submit', (event) => submitAddRecord(event, addMaterialForm, 'local.material'));
    const continueForm = root.querySelector('#continue-form');
    if (continueForm) continueForm.addEventListener('submit', (event) => submitAddRecord(event, continueForm, 'continuation'));
    const sourceForm = root.querySelector('#add-source-form');
    if (sourceForm) sourceForm.addEventListener('submit', (event) => submitAddConfiguredSource(event, sourceForm));
    root.querySelectorAll('[data-dialog-close]').forEach((button) => button.addEventListener('click', () => { dialog = null; notice = ''; render(); }));
    root.querySelectorAll('[data-confirm-close]').forEach((button) => button.addEventListener('click', () => {
      const result = lifecycle.closeWorkspace(state, button.getAttribute('data-confirm-close'));
      dialog = null;
      commit(result.state, 'push');
    }));
  }

  function goHome() {
    dialog = null;
    notice = '';
    commit(lifecycle.makeEmptyAppState(), 'push');
  }

  function submitCreateWorkspace(event, createForm) {
    event.preventDefault();
    const input = createForm.querySelector('[name="workspaceName"]');
    const result = lifecycle.createWorkspace(state, { name: input?.value || '' });
    if (!result.ok && result.error === 'workspace.name.required') {
      createForm.querySelector('[data-form-error]').textContent = 'Workspace name is required.';
      input?.focus();
      return;
    }
    dialog = null;
    commit(result.state, 'push');
  }

  function openDialog(type) {
    dialog = { type };
    render();
    if (type === 'create-workspace') root.querySelector('[name="workspaceName"]')?.focus();
  }

  function openCloseDialog(workspaceId) {
    const workspace = state.workspaces.find((item) => item.id === workspaceId);
    dialog = { type: 'close-workspace', workspace };
    render();
  }

  function openWorkspaceAction(action, workspaceId) {
    const workspace = state.workspaces.find((item) => item.id === workspaceId) || lifecycle.activeWorkspace(state);
    if (!workspace) return;
    if (action === 'add-material') dialog = { type: 'add-material', workspace };
    else if (action === 'add-source') dialog = { type: 'add-source', workspace };
    else if (action === 'continue') dialog = { type: 'continue', workspace };
    else if (action === 'open') dialog = { type: 'open-workspace', workspace };
    else dialog = { type: 'command-info', workspace, action };
    render();
    root.querySelector('[name="recordTitle"]')?.focus();
  }

  function submitAddRecord(event, form, kind) {
    event.preventDefault();
    const workspaceId = form.getAttribute('data-workspace-id') || state.activeWorkspaceId;
    const titleInput = form.querySelector('[name="recordTitle"]');
    const summaryInput = form.querySelector('[name="recordSummary"]');
    const fallbackTitle = kind === 'continuation' ? 'Continuation leaf' : 'Local material';
    const result = lifecycle.addWorkspaceRecord(state, workspaceId, {
      title: titleInput?.value || fallbackTitle,
      summary: summaryInput?.value || '',
      kind,
      status: kind === 'continuation' ? 'draft' : 'local'
    });
    if (!result.ok && result.error === 'record.title.required') {
      form.querySelector('[data-form-error]').textContent = 'Title is required.';
      titleInput?.focus();
      return;
    }
    dialog = null;
    notice = '';
    commit(result.state, 'push');
  }


  function submitAddConfiguredSource(event, form) {
    event.preventDefault();
    const workspaceId = form.getAttribute('data-workspace-id') || state.activeWorkspaceId;
    const entry = sourcePresenter().configuredEntrypoint(workspaceConfig);
    const result = lifecycle.addWorkspaceSource(state, workspaceId, {
      label: entry.label || entry.repository || 'Tiinex/docs',
      repository: entry.repository || 'Tiinex/docs',
      ref: entry.ref || 'master',
      rootPath: entry.rootPath || '.topics',
      transportLabel: sourcePresenter().configuredMirrorLabel(workspaceConfig, entry.repository || 'Tiinex/docs')
    });
    if (!result.ok) return;
    dialog = null;
    notice = '';
    commit(result.state, 'push');
  }

  function closeWorkspaceSource(workspaceId, sourceId) {
    const result = lifecycle.closeWorkspaceSource?.(state, workspaceId, sourceId);
    if (!result?.ok) return;
    commit(result.state, 'push');
  }

  function copyShareUrl(url) {
    const value = url || cleanShareUrl();
    notice = 'Copy this URL from the field if clipboard access is blocked.';
    try {
      const copy = navigator?.clipboard?.writeText?.(value);
      if (copy?.then) copy.then(() => { notice = 'Clean link copied.'; render(); }).catch(() => render());
      else render();
    } catch (_) { render(); }
  }

  function renderApp(active) {
    const mode = 'DISCOVERY MODE';
    const emptyClass = active ? '' : ' tx-empty-stage-mode';
    return `
      <main class="tx-app tx-shell-visual-continuity tx-shell-pattern-parity tx-shell-legibility-corrected tx-shell-height-continuity tx-shell-scroll-owned tx-shell-column-fit tx-shell-icon-polish tx-shell-command-portable tx-shell-config-grounded tx-shell-route-grounded tx-shell-v111-workspace-fit tx-shell-v112-live-workspace tx-shell-v113-action-clarity tx-shell-v114-old-empty-workspace tx-shell-v115-source-progress tx-uc001-shell tx-uc001-empty-stage-parity${emptyClass}" data-uc="UC-001-empty-create-restore-close">
        ${renderGlobalDock(Boolean(active))}
        ${active ? `
        <section class="tx-workspace-window tx-focused-main-window tx-uc001-window" aria-label="Tiinex workspace window">
          ${sourcePresenter().renderWindowHeader(active, sourceContext())}
          ${sourcePresenter().renderSourceStrip(active, sourceContext())}
          ${active.discoveryProgress ? '' : renderWorkspaceDropHint(active)}
          ${renderModeStrip(mode)}
          ${sourcePresenter().renderProgress(active, sourceContext())}
          <div class="tx-primary-stage tx-column-primary-stage">${renderWorkspace(active)}</div>
        </section>
        <footer class="tx-footer">Powered by <strong>Tiinex</strong></footer>` : `${renderEmptyStage()}<footer class="tx-footer tx-empty-footer">Powered by <strong>Tiinex</strong></footer>`}
        ${dialog ? renderDialog() : ''}
      </main>`;
  }

  function renderGlobalDock(hasWorkspace) {
    const showPager = hasWorkspace && state.workspaces.length > 1;
    return `
      <nav class="tx-legacy-global-dock ${hasWorkspace ? 'tx-active-global-dock' : 'tx-empty-global-dock'} ${showPager ? 'tx-global-dock-paged' : 'tx-global-dock-fit'}" aria-label="Global actions">
        ${showPager ? `<button class="tx-nav-button tx-round-nav" type="button" title="Previous workspace">${icon('previous')}</button>` : ''}
        <span class="tx-dock-core tx-centered-dock-core">
          <span class="tx-dock-left"><button class="tx-nav-button tx-multiverse-switch" type="button" data-multiverse title="Change multiverse" aria-label="Change multiverse">${icon('multiverse')}</button><button class="tx-nav-button tx-primary-orb" type="button" data-create-workspace title="Create workspace">${icon('create')}<strong>Create</strong></button></span>
          <button class="tx-logo-orb tx-logo-home" type="button" data-home title="Tiinex home" aria-label="Tiinex home"><img src="./public/assets/tiinex-logo-white-transparent.png" alt=""></button>
          <span class="tx-dock-right"><button class="tx-nav-button tx-share-action" type="button" data-share title="Share">${icon('share')}<strong>Share</strong></button><button class="tx-nav-button" type="button" data-help title="Help" aria-label="Help">${icon('help')}</button></span>
        </span>
        ${showPager ? `<button class="tx-nav-button tx-round-nav" type="button" title="Next workspace">${icon('next')}</button>` : ''}
      </nav>`;
  }

  function renderWorkspaceDropHint(workspace) {
    if (!workspace || (workspace.records || []).length) return '';
    return `<div class="tx-workspace-drop-hint">Drop lineage files, configs, folders, or zips into this workspace · or use the source button above.</div>`;
  }

  function renderModeStrip(mode) {
    return `<div class="tx-mode-strip tx-legacy-main-mode" aria-label="Mode controls"><div id="main-mode-name" class="tx-mode-name">${mode}</div><div class="tx-segment" aria-label="Workspace verse"><button class="tx-button ${state.view.workspaceVerse === 'feed' ? 'tx-active' : ''}" data-verse="feed" type="button">Feed</button><button class="tx-button ${state.view.workspaceVerse === 'tree' ? 'tx-active' : ''}" data-verse="tree" type="button">Tree</button></div><input id="workspace-search" class="tx-search-input" type="search" value="${escapeHtml(state.view.query || '')}" placeholder="Search title/schema/source…" aria-label="Search loaded artifacts"></div>`;
  }

  function renderEmptyStage() {
    const subtitle = window.TiinexWorkspaceConfig?.emptyStageSubtitle?.(workspaceConfig) || 'Everything starts from somewhere.';
    return `<section class="tx-empty-stage tx-old-empty-stage tx-uc001-empty-start" aria-label="No workspace loaded" title="Use Create to start a local workspace"><p>${escapeHtml(subtitle)}</p></section>`;
  }

  function renderWorkspace(workspace) {
    const records = (workspace.records || []).filter(recordMatchesQuery);
    return `<section class="tx-column-feed tx-uc001-created-workspace" data-workspace-id="${escapeHtml(workspace.id)}"><div class="tx-reader-state">${badge(state.view.workspaceVerse)}${badge(`${records.length} shown`)}</div>${records.length ? records.map(renderRecordCard).join('') : renderWorkspaceEmptyState(workspace)}</section>`;
  }

  function renderWorkspaceEmptyState(workspace) {
    return `<div class="tx-empty-node-state" role="status" aria-live="polite">No nodes match this view.</div>`;
  }

  function renderRecordCard(record) {
    return `<article class="tx-artifact-card tx-legacy-artifact-card tx-record-card"><div class="tx-legacy-card-badges">${badge(record.status || 'open')}${badge(record.kind || 'artifact')}${badge(record.createdAt || 'local')}</div><header class="tx-legacy-card-body"><h3>${escapeHtml(record.title || 'Untitled')}</h3><p>${escapeHtml(record.summary || '')}</p></header><footer class="tx-artifact-actions tx-legacy-action-row">${actionButton('open', 'Open record', true, 'open', state.activeWorkspaceId)}</footer></article>`;
  }

  function renderLineageRootTrailingCard() { return `<article class="tx-lineage-terminal tx-lineage-root-card"><span>${icon('audit')}</span><p>Lineage root reached.</p></article>`; }

  function dialogPresenter() {
    return window.TiinexDialogPresenter || {};
  }

  function presenterContext() {
    return { icon, badge, escapeHtml };
  }

  function sourcePresenter() {
    return window.TiinexSourcePresenter || {};
  }

  function sourceContext() {
    return { icon, badge, statPill, escapeHtml, workspaceConfig };
  }

  function renderDialog() {
    if (dialog.type === 'close-workspace') return renderCloseDialog(dialog.workspace);
    if (dialog.type === 'multiverse') return renderMultiverseDialog();
    if (dialog.type === 'help') return renderHelpDialog();
    if (dialog.type === 'share') return renderShareDialog();
    if (dialog.type === 'add-material') return dialogPresenter().renderAddMaterialDialog(dialog.workspace, presenterContext());
    if (dialog.type === 'add-source') return sourcePresenter().renderAddSourceDialog(dialog.workspace, sourceContext());
    if (dialog.type === 'continue') return dialogPresenter().renderContinueDialog(dialog.workspace, presenterContext());
    if (dialog.type === 'open-workspace') return dialogPresenter().renderOpenWorkspaceDialog(dialog.workspace, presenterContext());
    if (dialog.type === 'command-info') return dialogPresenter().renderCommandInfoDialog(dialog, presenterContext());
    return renderCreateDialog();
  }

  function renderCreateDialog() {
    return `<div class="tx-dialog-backdrop" role="presentation"><section class="tx-dialog tx-workspace-create-dialog" role="dialog" aria-modal="true" aria-labelledby="create-workspace-title"><button class="tx-dialog-close" type="button" data-dialog-close aria-label="Close">${icon('close')}</button><div class="tx-mini-label">Workspace</div><h2 id="create-workspace-title">Create workspace</h2><p class="tx-muted">Name a local workspace. Add sources and files after it opens.</p><form id="create-workspace-form"><label class="tx-field"><span>Workspace name</span><input name="workspaceName" autocomplete="off" maxlength="72" required placeholder="Example: Documentation"></label><div class="tx-badges">${badge('local/session')}${badge('no GitHub guess')}${badge('hash + storage restore')}</div><p class="tx-form-error" data-form-error aria-live="polite"></p><button class="tx-button tx-primary tx-dialog-primary" type="submit">${icon('create')} Create workspace</button></form></section></div>`;
  }


  function renderCloseDialog(workspace) {
    return `<div class="tx-dialog-backdrop" role="presentation"><section class="tx-dialog tx-workspace-close-dialog" role="dialog" aria-modal="true" aria-labelledby="close-workspace-title"><button class="tx-dialog-close" type="button" data-dialog-close aria-label="Close">${icon('close')}</button><div class="tx-mini-label">Close</div><h2 id="close-workspace-title">Close workspace?</h2><p>This closes <strong>${escapeHtml(workspace?.name || 'this workspace')}</strong> from the current browser session. It does not delete source files, GitHub material, or local downloads.</p><div class="tx-dialog-actions"><button class="tx-button" type="button" data-dialog-close>Cancel</button><button class="tx-button tx-danger" type="button" data-confirm-close="${escapeHtml(workspace?.id || '')}">Close workspace</button></div></section></div>`;
  }

  function renderMultiverseDialog() {
    return `<div class="tx-dialog-backdrop" role="presentation"><section class="tx-dialog" role="dialog" aria-modal="true" aria-labelledby="multiverse-title"><button class="tx-dialog-close" type="button" data-dialog-close aria-label="Close">${icon('close')}</button><div class="tx-mini-label">Multiverse</div><h2 id="multiverse-title">Column multiverse</h2><p>Column is the only active universe while UC-001 is being proven. Additional verses stay unavailable until this happy path is stable.</p><div class="tx-badges">${badge('Column active')}${badge(`${state.workspaces.length} workspace${state.workspaces.length === 1 ? '' : 's'}`)}${badge('Map/Atlas frozen')}</div></section></div>`;
  }

  function renderHelpDialog() {
    const help = workspaceConfig.help || [];
    const items = help.slice(0, 4).map((item) => `<details class="tx-help-item"><summary>${escapeHtml(item.question)}</summary><p>${escapeHtml(item.body)}</p></details>`).join('');
    return `<div class="tx-dialog-backdrop" role="presentation"><section class="tx-dialog" role="dialog" aria-modal="true" aria-labelledby="help-title"><button class="tx-dialog-close" type="button" data-dialog-close aria-label="Close">${icon('close')}</button><div class="tx-mini-label">Help</div><h2 id="help-title">Workspace help</h2>${items || '<p>No help entries configured.</p>'}</section></div>`;
  }

  function renderShareDialog() {
    const url = cleanShareUrl();
    return `<div class="tx-dialog-backdrop" role="presentation"><section class="tx-dialog" role="dialog" aria-modal="true" aria-labelledby="share-title"><button class="tx-dialog-close" type="button" data-dialog-close aria-label="Close">${icon('close')}</button><div class="tx-mini-label">Share</div><h2 id="share-title">Share current view</h2><p>Hash state carries the current local view. Empty start keeps a clean URL.</p><label class="tx-field"><span>URL</span><input readonly value="${escapeHtml(url)}"></label>${notice ? `<p class="tx-form-note">${escapeHtml(notice)}</p>` : ''}<button class="tx-button tx-primary tx-dialog-primary" type="button" data-copy-share="${escapeHtml(url)}">${icon('share')} Copy clean link</button></section></div>`;
  }

  function cleanShareUrl() {
    if (!state.workspaces?.length) return `${location.origin || ''}${location.pathname || ''}${location.search || ''}`;
    return location.href || '';
  }

  function recordMatchesQuery(record) {
    const query = String(state.view.query || '').toLowerCase().trim();
    if (!query) return true;
    return `${record.title || ''} ${record.summary || ''} ${record.kind || ''}`.toLowerCase().includes(query);
  }

  function actionButton(iconName, label, labeled = false, action = '', workspaceId = '') { return `<button class="tx-action-button tx-legacy-action ${labeled ? 'tx-labeled-action' : ''}" type="button" title="${escapeHtml(label)}" ${action ? `data-workspace-action="${escapeHtml(action)}" data-workspace-id="${escapeHtml(workspaceId)}"` : ''}>${icon(iconName)}${labeled ? `<strong>${escapeHtml(label)}</strong>` : ''}</button>`; }
  function icon(name) { return `<svg class="tx-svg-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${iconPaths[name] || iconPaths.preview}</svg>`; }

  function statPill(iconName, count, title) {
    return `<span class="stat-pill tx-counter-pill" title="${escapeHtml(title || '')}">${icon(iconName)}<strong>${Number(count || 0)}</strong></span>`;
  }

  function badge(text) { return `<span class="tx-badge">${escapeHtml(text)}</span>`; }
  function escapeHtml(value) { return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;'); }
})();
